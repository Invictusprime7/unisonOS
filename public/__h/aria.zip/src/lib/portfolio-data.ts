import heroStudio from "@/assets/hero-studio.jpg";
import portrait from "@/assets/portrait.jpg";
import studioDesk from "@/assets/studio-desk.jpg";
import angelMist from "@/assets/angel-mist.png.asset.json";
import gentleHands from "@/assets/gentle-hands.png.asset.json";
import peraloIdeas from "@/assets/peralo-ideas.png.asset.json";
import thaiSpoon from "@/assets/thai-spoon.jpg.asset.json";
import claraCover from "@/assets/clara-sardine-scout-cover.jpg.asset.json";

export const artist = {
  name: "Ariann Norori",
  studio: "ARIA",
  role: "Creative digital designer & artist",
  email: "hello@ariannorori.com",
  portrait,
  studioDesk,
  heroStudio,
  introduction:
    "I’m a versatile Brand Designer focused on helping REAL brands market and launch REAL products. I've helped brands to produce custom product designs, illustrative children's books, marketing billboards, digital product experiences and more!",
  approach:
    "I begin with story and character, then choose the medium that can carry the idea most honestly. A commission might become a tactile picture-book spread, an expressive cast of characters, or a cinematic digital world. The visual language changes; my curiosity, clarity, and care remain constant.",
} as const;

export type PortfolioProject = {
  slug: string;
  index: string;
  title: string;
  year: string;
  discipline: string;
  summary: string;
  challenge: string;
  approach: string;
  outcome: string;
  image: string;
  alt: string;
  size: "wide" | "portrait" | "square";
  /** Show the whole artwork instead of cropping it to the frame. */
  showWhole?: boolean;
};

export const projects: PortfolioProject[] = [
  {
    slug: "bloom",
    index: "01",
    title: "Angel Mist",
    year: "—",
    discipline: "Digital lettering · 3D typography",
    summary:
      "A sculptural lettering piece pairing glossy lilac forms, sweeping arcs, and star details against a deep black background.",
    challenge:
      "The composition balances expressive, flowing letterforms with a clear reading of the words Angel Mist.",
    approach:
      "I bring together rounded lettering, pale pink-lilac highlights, and curved flourishes to give the piece a playful, sculptural presence.",
    outcome:
      "Angel Mist appears as a standalone digital artwork, with its glossy lettering and star accents framed by black negative space.",
    image: angelMist.url,
    alt: "Angel Mist in glossy pale lilac 3D lettering with sweeping arcs and star accents on black",
    size: "square",
  },
  {
    slug: "gentle-hands",
    index: "02",
    title: "Gentle Hands",
    year: "—",
    discipline: "Editorial design · Brochure layout",
    summary:
      "A warm print brochure for the Gentle Hands Foundation — “Teaching Patience, Learning Patience” — made to feel calm, kind, and easy to read.",
    challenge:
      "I needed to bring parenting tips, a feature article, and a caregiver play-group invitation together in one booklet that feels gentle rather than clinical.",
    approach:
      "I built a soft-blue and cream editorial system with rounded headlines, generous photography of families, and clear sections so each spread reads at an easy pace.",
    outcome:
      "A finished cover and inside spreads ready for print, with a layout the foundation can reuse for future issues and events.",
    image: gentleHands.url,
    alt: "Gentle Hands Foundation brochure: the “Teaching Patience, Learning Patience” cover beside an open spread of parenting tips and a play-group invitation",
    size: "wide",
    showWhole: true,
  },
  {
    slug: "thai-spoon",
    index: "03",
    title: "Thai Spoon & Sushi",
    year: "—",
    discipline: "Brand research · Restaurant identity",
    summary:
      "A look at Thai Spoon & Sushi — its warm, collected dining room and the many logos it has used over the years.",
    challenge:
      "The restaurant had two past logos and three different current ones, so its signs, menus, and storefront no longer told one story.",
    approach:
      "I gathered photos of the space — the samurai mural, red leather lounge, and daruma details — beside every logo to see what the brand already says and where it splits.",
    outcome:
      "A clear picture of the brand today, ready to guide one unified logo that matches the character of the room.",
    image: thaiSpoon.url,
    alt: "Thai Spoon & Sushi board: restaurant interior photos beside its two past logos and three current logos",
    size: "square",
    showWhole: true,
  },
  {
    slug: "peralo-styling",
    index: "04",
    title: "Peralo Styling",
    year: "—",
    discipline: "Logo design · Brand identity",
    summary:
      "A sheet of logo ideas for Peralo Styling, a fashion stylist — stilettos, pins, tape measures, and silhouettes woven into the name.",
    challenge:
      "I wanted to find a mark that felt elegant and fashion-forward while still hinting at the hands-on craft of styling.",
    approach:
      "I explored many directions in black and white — bold sans lettering, classic serifs, flowing script, and drawn fashion objects like a heel, a pincushion, and a measuring tape.",
    outcome:
      "A range of logo concepts that give the client clear choices, from playful illustrated marks to refined type-only wordmarks.",
    image: peraloIdeas.url,
    alt: "Black-and-white sheet of Peralo Styling logo ideas with a stiletto, pincushion, leopard scarf, portrait silhouette, measuring tape, and script lettering",
    size: "wide",
    showWhole: true,
  },
  {
    slug: "clara-sardine-scout-penguin",
    index: "05",
    title: "Clara · The Sardine Scout Penguin",
    year: "—",
    discipline: "Children’s book illustration · Character design",
    summary:
      "I illustrated Jayley Fairgrieves’ story of Clara, a penguin scout who discovers that courage, kindness, and new friendships matter more than winning.",
    challenge:
      "I brought Clara’s journey from familiar snowy neighborhoods into an unfamiliar underwater world to life, keeping her emotions and the story easy for young readers to follow.",
    approach:
      "I paired expressive penguin characters with soft, textured snow scenes and colorful sea creatures. Clara’s blue feathers, glasses, and scout sash connect her adventures across the book.",
    outcome:
      "An illustrated picture book with a playful cover and a complete sequence of story scenes. Story by Jayley Fairgrieves; art by Ariann Norori.",
    image: claraCover.url,
    alt: "Clara: The Sardine Scout Penguin book cover, featuring a blue penguin with glasses and a scout sash, a smiling narwhal, and a purple penguin in a snowy landscape",
    size: "square",
    showWhole: true,
  },
];

export function getProject(slug: string) {
  return projects.find((project) => project.slug === slug);
}

export const commissionSteps = [
  ["01", "Listen", "A focused conversation about the story, audience, and feeling the work needs to carry."],
  ["02", "Discover", "Visual research, sketches, and character studies reveal the most promising creative route."],
  ["03", "Make", "I develop the chosen direction through considered rounds of drawing, design, and refinement."],
  ["04", "Release", "Final artwork arrives prepared for its real setting, with the files and guidance needed to use it well."],
] as const;