import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { projects } from "../data";

export default defineTool({
  name: "get_project",
  title: "Get project",
  description: "Get details for a single portfolio project by its slug (see list_projects).",
  inputSchema: {
    slug: z.string().describe("Project slug, e.g. 'bloom' or 'peralo-styling'."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ slug }) => {
    const project = projects.find((p) => p.slug === slug);
    if (!project) {
      throw new ToolError(
        `Unknown project slug "${slug}". Available: ${projects.map((p) => p.slug).join(", ")}.`,
      );
    }
    return {
      content: [
        {
          type: "text",
          text: `${project.title} (${project.year})\n${project.discipline}\n\n${project.summary}`,
        },
      ],
      structuredContent: {
        project: {
          slug: project.slug,
          title: project.title,
          year: project.year,
          discipline: project.discipline,
          summary: project.summary,
        },
      },
    };
  },
});
