import { defineTool } from "@lovable.dev/mcp-js";
import { projects } from "../data";

const toProjectJson = (p: (typeof projects)[number]) => ({
  slug: p.slug,
  title: p.title,
  year: p.year,
  discipline: p.discipline,
  summary: p.summary,
});

export default defineTool({
  name: "list_projects",
  title: "List projects",
  description: "List the artist's selected portfolio projects with year, discipline and a short summary.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => ({
    content: [
      {
        type: "text",
        text: projects.map((p) => `${p.title} (${p.year}) — ${p.discipline}`).join("\n"),
      },
    ],
    structuredContent: { projects: projects.map(toProjectJson) },
  }),
});
