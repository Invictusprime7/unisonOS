import { defineTool } from "@lovable.dev/mcp-js";
import { artist, process } from "../data";

export default defineTool({
  name: "get_studio_info",
  title: "Get studio info",
  description:
    "Get the artist's bio, location, contact email, commission availability and working process.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => ({
    content: [
      {
        type: "text",
        text: [
          `${artist.name} — ${artist.role}`,
          `Based in ${artist.location}. Contact: ${artist.email}`,
          "",
          artist.bio,
          "",
          artist.commissionsOpen ? artist.commissionsNote : "Commissions currently closed.",
          "",
          "Process: " + process.map((s) => s.step).join(" → "),
        ].join("\n"),
      },
    ],
    structuredContent: {
      artist: {
        name: artist.name,
        role: artist.role,
        location: artist.location,
        email: artist.email,
        bio: artist.bio,
        commissionsOpen: artist.commissionsOpen,
        commissionsNote: artist.commissionsNote,
        socials: artist.socials.map((s) => ({ label: s.label, url: s.url })),
      },
      process: process.map((s) => ({ step: s.step, detail: s.detail })),
    },
  }),
});
