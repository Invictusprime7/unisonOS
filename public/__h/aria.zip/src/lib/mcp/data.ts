/**
 * Public portfolio data served by the ARIA MCP server.
 * Public ARIA portfolio identity and project summaries.
 */

export interface PortfolioProject {
  slug: string;
  title: string;
  year: number | string;
  discipline: string;
  summary: string;
}

export const artist = {
  name: "Ariann Norori",
  role: "Creative digital designer & artist",
  location: "Available for remote commissions",
  email: "hello@ariannorori.com",
  workingSince: 2020,
  bio: "Ariann Norori creates illustrative children’s books, original characters, custom portfolio art, and expressive digital experiences through ARIA.",
  commissionsOpen: true,
  commissionsNote:
    "Selected commissions are open for children’s illustration, character design, and custom digital art.",
  socials: [
    { label: "Instagram", url: "https://instagram.com/" },
    { label: "Are.na", url: "https://are.na/" },
    { label: "LinkedIn", url: "https://linkedin.com/" },
  ],
} as const;

export const projects: PortfolioProject[] = [
  {
    slug: "bloom",
    title: "Bloom",
    year: 2024,
    discipline: "Children’s publishing · Illustration",
    summary:
      "A bright picture-book world where tiny garden characters learn that growing happens at different speeds.",
  },
  {
    slug: "gentle-hands",
    title: "Gentle Hands",
    year: 2023,
    discipline: "Editorial design · Brochure layout",
    summary:
      "A warm editorial brochure for the Gentle Hands Foundation — parenting tips, a feature article, and a caregiver play-group invitation.",
  },
  {
    slug: "thai-spoon",
    title: "Thai Spoon & Sushi",
    year: 2023,
    discipline: "Brand research · Restaurant identity",
    summary:
      "A brand review of Thai Spoon & Sushi — its dining room and the five logos it has used over the years.",
  },
  {
    slug: "peralo-styling",
    title: "Peralo Styling",
    year: 2022,
    discipline: "Logo design · Brand identity",
    summary:
      "Logo ideas for Peralo Styling, a fashion stylist — heels, pins, tape measures, and silhouettes woven into the name.",
  },
  {
    slug: "clara-sardine-scout-penguin",
    title: "Clara · The Sardine Scout Penguin",
    year: "—",
    discipline: "Children’s book illustration · Character design",
    summary:
      "A children’s picture book written by Jayley Fairgrieves and illustrated by Ariann Norori, following Clara the penguin scout from the Arctic to the sea.",
  },
];

export const process = [
  {
    step: "Brief",
    detail:
      "A short call or email. You tell me the shape of the thing — what it is, who it's for, when it's due.",
  },
  {
    step: "Direction",
    detail:
      "I return a proposal with scope, a fixed price and two or three art-direction routes within two days.",
  },
  {
    step: "Making",
    detail:
      "We work directly, no middle layer. Sketches, drafts and finals land in a shared studio space.",
  },
  {
    step: "Delivery",
    detail:
      "Print-ready files, motion packages and a small system document — everything you need to run it.",
  },
] as const;
