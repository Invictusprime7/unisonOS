import { defineMcp } from "@lovable.dev/mcp-js";
import listProjectsTool from "./tools/list-projects";
import getProjectTool from "./tools/get-project";
import getStudioInfoTool from "./tools/get-studio-info";

export default defineMcp({
  name: "aria",
  title: "ARIA",
  version: "0.1.0",
  instructions:
    "ARIA is the portfolio of an independent digital designer and artist. Use `list_projects` and `get_project` to explore selected work, and `get_studio_info` for the bio, contact email and commission process.",
  tools: [listProjectsTool, getProjectTool, getStudioInfoTool],
});
