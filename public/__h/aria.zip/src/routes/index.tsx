import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import { type PointerEvent, useEffect, useRef, useState } from "react";
import { SiteFooter, SiteNav } from "@/components/SiteChrome";
import { artist, commissionSteps, projects } from "@/lib/portfolio-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ARIA — Ariann Norori, Creative Digital Designer & Artist" },
      { name: "description", content: "ARIA is Ariann Norori’s creative practice spanning children’s illustration, character design, custom digital art, and portfolio experiences. Explore selected work and the commission process." },
      { property: "og:title", content: "ARIA — Ariann Norori" },
      { property: "og:description", content: "Children’s illustration, character design, and custom digital art by Ariann Norori." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});

function ImmersiveImage({ src, alt, showWhole }: { src: string; alt: string; showWhole?: boolean }) {
  const frameRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const frame = frameRef.current;
    if (!frame) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const box = frame.getBoundingClientRect();
      const progress = (box.top + box.height / 2 - window.innerHeight / 2) / window.innerHeight;
      frame.style.setProperty("--aria-scroll", String(Math.max(-1, Math.min(1, progress))));
    };
    const queue = () => { if (!raf) raf = requestAnimationFrame(update); };
    update();
    window.addEventListener("scroll", queue, { passive: true });
    window.addEventListener("resize", queue);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("scroll", queue); window.removeEventListener("resize", queue); };
  }, []);

  const tilt = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse") return;
    const box = event.currentTarget.getBoundingClientRect();
    event.currentTarget.style.setProperty("--aria-tilt-x", String(((event.clientX - box.left) / box.width - 0.5) * 2));
    event.currentTarget.style.setProperty("--aria-tilt-y", String(((event.clientY - box.top) / box.height - 0.5) * 2));
  };
  const reset = (event: PointerEvent<HTMLDivElement>) => {
    event.currentTarget.style.setProperty("--aria-tilt-x", "0");
    event.currentTarget.style.setProperty("--aria-tilt-y", "0");
  };

  return <div ref={frameRef} onPointerMove={tilt} onPointerLeave={reset} className="aria-immersive h-full w-full">
    <img src={src} alt={alt} className={`aria-immersive__image h-full w-full ${showWhole ? "object-contain" : "object-cover"}`} />
  </div>;
}

function ProcessSlideshow() {
  const [activeStep, setActiveStep] = useState(0);
  const step = commissionSteps[activeStep];
  const image = projects[activeStep];

  const move = (direction: number) => {
    setActiveStep((current) => (current + direction + commissionSteps.length) % commissionSteps.length);
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") move(-1);
      if (event.key === "ArrowRight") move(1);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  if (!step || !image) return null;

  return (
    <section aria-label="Commission process slideshow" className="relative border-y border-border bg-card/40 px-6 py-20 sm:px-10 sm:py-28">
      <div className="pointer-events-none absolute left-4 top-0 select-none font-serif text-9xl font-bold italic leading-none text-primary/10 sm:left-10 sm:text-[15rem]" aria-hidden="true">{step[0]}</div>
      <div className="relative mx-auto grid min-h-[42rem] max-w-7xl items-center gap-16 lg:grid-cols-12">
        <div className="relative lg:col-span-7">
          <div className="aspect-[4/5] overflow-hidden bg-muted sm:aspect-[16/10]">
            <img key={image.slug} src={image.image} alt={image.alt} className="ut-process-frame h-full w-full object-cover" />
          </div>
          <div className="relative -mt-12 ml-auto w-4/5 border border-border bg-background p-6 sm:-mr-10 sm:w-2/5 sm:p-8">
            <p className="font-mono text-xs uppercase text-primary">Next chapter</p>
            <p className="mt-4 font-serif text-xl italic leading-snug">{commissionSteps[(activeStep + 1) % commissionSteps.length]?.[2]}</p>
          </div>
        </div>

        <div className="lg:col-span-5 lg:pl-12">
          <p className="font-mono text-xs uppercase text-primary">Phase {step[0]} · {activeStep + 1} of {commissionSteps.length}</p>
          <h2 className="mt-5 font-serif text-5xl font-bold italic leading-none sm:text-7xl">{step[1]}</h2>
          <p className="mt-8 max-w-md text-lg leading-relaxed text-muted-foreground">{step[2]}</p>
          <div className="mt-12 flex items-center justify-between border-t border-border pt-6">
            <div className="flex gap-3" aria-label="Choose a process phase">
              {commissionSteps.map(([number, title], index) => <button key={number} type="button" onClick={() => setActiveStep(index)} aria-label={`Show ${title}`} aria-current={index === activeStep ? "step" : undefined} className={`h-2 w-2 rounded-full transition-colors ${index === activeStep ? "bg-primary" : "bg-border hover:bg-muted-foreground"}`} />)}
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => move(-1)} aria-label="Previous process phase" className="grid h-11 w-11 place-items-center border border-border text-foreground transition-colors hover:border-primary hover:text-primary"><ArrowLeft size={18} aria-hidden="true" /></button>
              <button type="button" onClick={() => move(1)} aria-label="Next process phase" className="grid h-11 w-11 place-items-center border border-border text-foreground transition-colors hover:border-primary hover:text-primary"><ArrowRight size={18} aria-hidden="true" /></button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HomePage() {
  return (
    <div className="relative isolate min-h-screen overflow-hidden bg-background text-foreground">
      <SiteNav />
      <main className="relative z-10">
        <section className="relative min-h-[75vh] w-full overflow-hidden">
          <div className="absolute inset-0 grayscale">
            <img src={artist.heroStudio} alt="Ariann Norori’s atmospheric creative studio" className="ut-kenburns h-full w-full object-cover" />
            <div className="aria-hero-veil absolute inset-0" />
          </div>
          <div className="aria-hero-foreground relative z-10 mx-auto flex min-h-[75vh] max-w-7xl flex-col justify-end px-6 pb-20 pt-32 sm:px-10 sm:pb-20">
            <div className="flex items-center gap-5">
              <span className="h-px w-12 bg-background" />
              <p className="ut-rise font-mono text-xs uppercase opacity-80">Creative digital designer & artist</p>
            </div>
            <h1 className="ut-rise mt-8 font-serif text-8xl font-bold italic leading-none sm:text-9xl lg:text-[10rem]">ARIA</h1>
            <p className="mt-10 max-w-lg text-lg font-light leading-relaxed opacity-85 sm:text-xl">{artist.introduction}</p>
            <div className="mt-10 flex flex-wrap items-center gap-10">
              <Link to="/work" className="aria-hero-action border border-background px-8 py-4 font-mono text-xs uppercase transition-colors">Explore work</Link>
              <a href="#process" className="ut-link-caps opacity-80 transition-opacity hover:opacity-100">The process</a>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-6 py-24 sm:px-10 sm:py-32">
          <div className="mb-14 flex items-end justify-between border-b border-border pb-5">
            <h2 className="font-serif text-4xl italic sm:text-6xl">Selected worlds</h2>
            <Link to="/work" className="ut-link-caps text-primary">View all work</Link>
          </div>
          <div className="grid grid-cols-1 items-start gap-x-8 gap-y-20 sm:grid-cols-12">
            {projects.map((project, index) => (
              <article key={project.slug} className={`${index === 4 ? "sm:col-span-5 sm:col-start-8 sm:-mt-[var(--ut-section-space)]" : project.size === "wide" ? "sm:col-span-7" : "sm:col-span-5"} ${index === 1 ? "sm:mt-24" : ""} ${index === 3 ? "sm:-mt-20" : ""} group`}>
                <Link to="/process/$slug" params={{ slug: project.slug }}>
                  <div className={`${project.size === "portrait" ? "aspect-[4/5]" : project.size === "square" ? "aspect-square" : "aspect-[16/10]"} overflow-hidden bg-card`}>
                    <ImmersiveImage src={project.image} alt={project.alt} showWhole={project.showWhole} />
                  </div>
                  <div className="mt-5 flex items-baseline justify-between gap-4">
                    <h3 className="font-serif text-2xl italic sm:text-3xl">{project.title}</h3>
                    <span className="font-mono text-xs uppercase text-muted-foreground">{project.year}</span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{project.discipline}</p>
                </Link>
              </article>
            ))}
          </div>
        </section>

        <section id="process" className="scroll-mt-24">
          <header className="mx-auto max-w-7xl px-6 pb-16 pt-16 sm:px-10 sm:pt-24">
            <p className="font-mono text-xs uppercase text-primary">Working together · Four chapters</p>
            <h2 className="mt-6 max-w-5xl font-serif text-4xl font-bold italic leading-tight sm:text-5xl lg:text-6xl">A process built around your story.</h2>
            <p className="mt-10 max-w-xl leading-relaxed text-muted-foreground sm:ml-auto">I keep each commission clear and collaborative, while leaving enough space for discovery and the unexpected idea that changes everything.</p>
          </header>
          <ProcessSlideshow />
          <section className="border-t border-border px-6 py-24 sm:px-10">
            <div className="mx-auto max-w-7xl">
              <div className="flex items-end justify-between gap-8">
                <p className="font-mono text-xs uppercase text-primary">Process in practice</p>
                <Link to="/work" className="ut-link-caps text-primary">View all work</Link>
              </div>
              <div className="mt-10 grid gap-8 sm:grid-cols-2">
                {projects.slice(0, 2).map(project => (
                  <Link key={project.slug} to="/process/$slug" params={{ slug: project.slug }} className="group">
                    <img src={project.image} alt={project.alt} className={`aspect-[16/10] w-full ${project.showWhole ? "object-contain" : "object-cover"} transition-transform duration-700 group-hover:scale-[1.03]`} />
                    <h3 className="mt-4 font-serif text-3xl italic">{project.title}</h3>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        </section>

      </main>
      <div className="relative z-10"><SiteFooter /></div>
    </div>
  );
}
