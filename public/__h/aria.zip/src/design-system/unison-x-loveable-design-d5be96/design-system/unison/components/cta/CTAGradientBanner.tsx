/**
 * CTA Variant: Gradient Banner
 * Full-width gradient background with bold headline and buttons.
 * High-visibility, immersive call-to-action.
 */

import React from 'react';
import type { BaseSectionProps } from '../../types';
import { hsl, hsla } from '../../themeUtils';

export const CTAGradientBanner: React.FC<BaseSectionProps<'cta'>> = ({ section, theme }) => {
  const { headline, description, ctas = [] } = section.props;

  return (
    <section
      data-ut-variant="cta:gradient-banner"
      className="relative overflow-hidden text-center"
      style={{
        padding: '5rem 1rem',
        background: `linear-gradient(135deg, ${hsl(theme.colors.primary)}, ${hsl(theme.colors.secondary)})`,
      }}
    >
      {/* Decorative overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, ${hsla(theme.colors.primaryForeground, 0.3)} 0%, transparent 50%), radial-gradient(circle at 80% 50%, ${hsla(theme.colors.primaryForeground, 0.2)} 0%, transparent 50%)`,
        }}
      />

      <div className="mx-auto px-6 relative" style={{ maxWidth: '700px' }}>
        <h2 data-ut-slot="cta.headline"
          className="text-3xl md:text-4xl mb-4"
          style={{
            fontFamily: theme.typography.headingFont,
            fontWeight: theme.typography.headingWeight,
            color: hsl(theme.colors.primaryForeground),
            letterSpacing: 0,
          }}
        >
          {headline}
        </h2>
        {description && (
          <p data-ut-slot="cta.description"
            className="text-base max-w-lg mx-auto mb-8"
            style={{ fontFamily: theme.typography.bodyFont, color: hsla(theme.colors.primaryForeground, 0.85) }}
          >
            {description}
          </p>
        )}
        <div data-ut-slot="cta.actions" className="flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:flex-wrap sm:items-center">
          {ctas.map((c, i) => (
            <a
              key={i}
              href={c.href || '#'}
              data-ut-intent={c.intent ?? 'nav.goto'}
              data-ut-cta={i === 0 ? 'cta.hero' : 'cta.hero-secondary'}
              className="inline-block text-sm font-medium px-6 py-3 motion-safe:transition-opacity hover:opacity-90"
              style={
                c.variant === 'outline'
                  ? {
                      background: 'transparent',
                      color: hsl(theme.colors.primaryForeground),
                      border: `1px solid ${hsla(theme.colors.primaryForeground, 0.4)}`,
                      borderRadius: theme.radius,
                    }
                  : {
                      background: hsl(theme.colors.primaryForeground),
                      color: hsl(theme.colors.primary),
                      borderRadius: theme.radius,
                      fontWeight: '600',
                    }
              }
            >
              {c.label}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};
