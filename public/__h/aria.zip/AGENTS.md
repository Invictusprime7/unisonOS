# AGENTS.md — Structural decisions

## Styling stack
- Tailwind v4 is wired via `@tailwindcss/vite` (default import) in `vite.config.ts` plugins, ahead of the TanStack/React plugins. The project ships no `tailwind.config.js`.
- `src/styles.css` is the CSS entry: `@import "tailwindcss"`, then the Unison design-system tokens (`tokens.css`), then `@source` directives scanning `src/design-system/**` and `src/**`, then a `:root` project-theme layer that maps the brand palette onto the Unison semantic tokens (`--background`, `--primary`, etc.) and overrides `--ut-font-*`.
- Art direction is SEALED to the Unison `cinematic-portfolio` pack (Editorial family, seed aria-001) — recorded in `src/lib/unison-brief.ts`; later pages must not re-interpret it.
- Brand palette is Gallery Paper (off-white paper, warm white surfaces, near-black ink, muted orchid accent); fonts are Libre Baskerville display, IBM Plex Sans body, and JetBrains Mono eyebrow caps. These remain project-layer overrides so the sealed cinematic pack does not change.
- Web fonts load via `<link>` in `src/routes/__root.tsx` head, never `@import` in CSS.
- A fixed atmospheric layer provides restrained perspective motion on the Work route only; it is decorative, pointer-inert, and disabled under reduced-motion preferences.
- Homepage gallery motion stays in a project-local image wrapper with automatic staggered drift, scroll parallax, and pointer tilt; the user-requested reduced-motion override is scoped to this gallery so unrelated motion retains its accessibility behavior.

## Routing
- ARIA uses distinct routes for Home, Work, Process, project case studies, and Contact; Archive and About are intentionally excluded to keep discovery focused.
