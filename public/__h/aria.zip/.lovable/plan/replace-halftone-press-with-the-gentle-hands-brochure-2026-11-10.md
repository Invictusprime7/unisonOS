# Replace "Halftone Press" with the Gentle Hands brochure

Same approach as Angel Mist: swap the second project's image (the one you selected) for your uploaded brochure and rewrite its text to match.

## Changes
- Upload the brochure image to the CDN and use it for the second project card, its case study, and the Work page.
- Rewrite that project's text (first-person):
  - Title: "Gentle Hands"
  - Discipline: "Editorial design · Brochure layout"
  - Year: "—" (like Angel Mist, until you give me the real year)
  - Summary, challenge, approach, outcome: a print brochure for the Gentle Hands Foundation — "Teaching Patience, Learning Patience" — with a warm, soft-blue editorial system for parenting tips, articles, and a caregiver play-group invitation.
  - Alt text describing the open brochure spread and cover.
- Case-study link changes from /process/halftone-press to /process/gentle-hands.

## Technical details
- `lovable-assets create` -> `src/assets/gentle-hands.png.asset.json`; import in `src/lib/portfolio-data.ts`, set `image: gentleHands.url`, slug `gentle-hands`.
- Mirror the text update in `src/lib/mcp/data.ts`.
