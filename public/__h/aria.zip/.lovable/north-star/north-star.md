<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Clients get original artwork commissioned from the artist.

## Metric

Clients who submit a commission quote request each month
