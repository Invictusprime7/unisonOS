import styles from './card.module.scss';
const pages = import.meta.glob('./sections/*.ts', { eager: true, import: 'default' }) as Record<string, string>;
document.getElementById('app')!.innerHTML = `<div class="card"><h2 class="${styles.title}">Sass card</h2>${Object.values(pages).map((t) => `<p>${t}</p>`).join('')}</div>`;
