import clsx from 'clsx';
export function Button({ children, primary }: { children: React.ReactNode; primary?: boolean }) {
  return <button className={clsx('btn', primary && 'btn-primary')} style={{ padding: '12px 20px', background: primary ? '#111' : '#eee', color: primary ? '#fff' : '#111', border: 0, borderRadius: 8 }}>{children}</button>;
}
