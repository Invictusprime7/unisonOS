import { createRoot } from 'react-dom/client';
import { Button, brand } from '@acme/ui';
import { Hero } from '~/Hero';
createRoot(document.getElementById('root')!).render(<main><Hero name={brand} /><Button primary>Get started</Button></main>);
