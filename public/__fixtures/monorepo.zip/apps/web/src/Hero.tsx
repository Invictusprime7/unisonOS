export function Hero({ name }: { name: string }) { return <h1 style={{ fontFamily: 'Georgia, serif', fontSize: 48 }}>{name} monorepo app</h1>; }
